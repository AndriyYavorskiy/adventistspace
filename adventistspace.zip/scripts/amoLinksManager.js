angular.module('AMO')
.factory('amoLinksManager', ['$window', function ($window) {
  var manager = {};
  manager.addOne = function (link, folderId) {
    if (!link && !link.link) {return}
    var freshModel = manager.getLinks();
    if (folderId) {

    } else {
      freshModel.default.unshift(link);
    }
    _setLinks(freshModel);
  };
  manager.deleteOne = function (link, folderId) {
    if (!link && !link.link) {return}
    var freshModel = manager.getLinks();
    if (folderId) {

    } else {
      freshModel = freshModel.default.filter(function (item) {
        return item.link !== link.link && item.name !== link.name;
      });
    }
    _setLinks(freshModel);
  }
  manager.updateOne = function (link, folderId) {
    if (!link && !link.link) {return}
    var freshModel = manager.getLinks();
    if (folderId) {

    } else {
      freshModel = freshModel.default.filter(function (item) {
        return item.link !== link.link && item.name !== link.name;
      });
      freshModel.unshift(link);
    }
    _setLinks(freshModel);
  }
  manager.getLinks = function () {
    return _getLinks() || _getInitialModel();
  }

  return manager;

  function _setLinks (links) {
    $window.localStorage.setItem('amo-links', JSON.stringify(links));
  }
  function _getLinks () {
    return JSON.parse($window.localStorage.getItem('amo-links'));
  }
  function _getInitialModel () {
    return {
      "default": [],
      "folders": []
    };
  }
}]);